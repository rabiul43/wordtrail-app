/* The whole app lives inside this one closure; 999-app-close.js closes it. */
(() => {
