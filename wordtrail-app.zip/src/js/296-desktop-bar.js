  /* ------ desktop: the bottom player bar on Home and the track list beside the text ------
     Styles are in src/css/98-desktop-layout.css (they only apply from 1100px wide). The bar reuses the existing player buttons and seek bar, so no
     audio code changes: back/forward click the dock buttons, the seek bar drives #seek. dtSeekSync is called from updateSeekUI (150). */
  const DT_WIDE = window.matchMedia ? window.matchMedia('(min-width: 1100px)') : { matches: false };
  function dtSeekSync(t, d) {
    const sk = $('#mini-seek'); if (!sk) return;
    const w = playWin(S.sec), r = Math.min(w.d, Math.max(0, t - w.a));
    $('#mini-cur').textContent = fmt(r);
    $('#mini-left').textContent = '-' + fmt(Math.max(0, w.d - r));
    sk.min = w.a; sk.max = w.b || 100;
    if (!sk._drag) sk.value = t;
    sk.style.setProperty('--fill', (w.d ? Math.min(100, r / w.d * 100) : 0) + '%');
  }
  let dtKey = '';
  function dtTracks() {
    const box = $('#dt-tracks'); if (!box) return;
    const list = $('.dt-list', box), b = S.book;
    if (!DT_WIDE.matches || !b || !S.secs || !S.secs.length) { if (!b) { list.textContent = ''; dtKey = ''; } return; }
    const base = b.id + ':' + S.secs.length + ':', key = base + S.sec;
    if (key === dtKey) return;
    const same = dtKey.indexOf(base) === 0 && list.children.length === S.secs.length;
    dtKey = key;
    if (!same) {
      list.textContent = '';
      S.secs.forEach((s, i) => list.append(h('button', { class: 'dt-track', type: 'button', onclick: () => goTrack(i, 0, true) },
        h('span', { class: 'n' }, String(i + 1)), h('span', { class: 'tt' }, s.title || ('Track ' + (i + 1))), h('span', { class: 'd' }, S.durs[i] ? fmt(S.durs[i]) : ''))));
    }
    Array.from(list.children).forEach((r, i) => { if (i === S.sec) r.setAttribute('aria-current', 'true'); else r.removeAttribute('aria-current'); });
    const cur = list.children[S.sec]; if (cur && cur.scrollIntoView) cur.scrollIntoView({ block: 'nearest' });
  }
  /* collapse / expand the left panel (cover + title + tracks). The choice is remembered on this device (wt:dt-side) and the [ key does the same. */
  const DT_SIDE_KEY = 'wt:dt-side';
  function dtSide(off, save) {
    const rd = $('#reader'), b = $('#dt-side'); if (!rd || !b) return;
    rd.classList.toggle('side-off', off);
    const label = off ? 'Show track panel' : 'Hide track panel';
    b.setAttribute('aria-expanded', off ? 'false' : 'true'); b.setAttribute('aria-label', label); b.title = label + ' ( [ )';
    if (save) store.set(DT_SIDE_KEY, off ? 1 : 0);
  }
  function dtSideToggle() {
    if (!DT_WIDE.matches || el.player.hidden) return;
    const rd = $('#reader'); if (rd) dtSide(!rd.classList.contains('side-off'), true);
  }
  function dtInit() {
    const sb = $('#dt-side');
    document.addEventListener('keydown', e => {   // [ hides or shows the panel (only while a book is open and nothing is being typed)
      if (e.key !== '[' || e.ctrlKey || e.metaKey || e.altKey || el.player.hidden || !el.backdrop.hidden) return;
      if (e.target.closest('input, textarea, select')) return;
      e.preventDefault(); dtSideToggle();
    });
    if (sb) { sb.addEventListener('click', dtSideToggle); dtSide(store.get(DT_SIDE_KEY, 0) === 1, false); }
    const sk = $('#mini-seek');
    if (sk) {
      sk.addEventListener('input', () => { sk._drag = true; el.seek.value = sk.value; sk.style.setProperty('--fill', (sk.value / (+sk.max || 1) * 100) + '%'); el.seek.dispatchEvent(new Event('input')); });
      sk.addEventListener('change', () => { sk._drag = false; el.seek.dispatchEvent(new Event('change')); });
    }
    const back = $('#mini-back'), fwd = $('#mini-fwd');
    if (back) back.addEventListener('click', () => $('#b-back15').click());
    if (fwd) fwd.addEventListener('click', () => $('#b-fwd15').click());
    ['#p-sub', '#p-title'].forEach(q => { const n = $(q); if (n && window.MutationObserver) new MutationObserver(dtTracks).observe(n, { childList: true, characterData: true, subtree: true }); });
    audio.addEventListener('loadedmetadata', dtTracks);
    if (DT_WIDE.addEventListener) DT_WIDE.addEventListener('change', dtTracks);
    dtTracks();
  }
  try { dtInit(); } catch (e) { /* the desktop extras are optional: the app works without them */ }
